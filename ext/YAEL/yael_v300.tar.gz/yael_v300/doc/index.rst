Welcome to Yael's documentation!
================================

.. toctree::
   :maxdepth: 2

   whatisthis
   gettingstarted
   cinterface
   python_interface
   matlab_interface
   file_format
   troubleshooting


.. These images will have to be included
  .. image:: figs/logoinria.png
     :height: 100px
  .. image:: figs/logoyael.png
     :height: 100px
     :align: right


